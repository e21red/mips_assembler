/* empty_slot.c */
void empty_slot_init(hwaddr addr, uint64_t slot_size);
